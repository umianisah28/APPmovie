# CatalogueMovie


The 1st submission from dicoding.com online course **MADE(Menjadi Android Developer Expert)**. Create the searching movie apps from the catalogue using api.themoviedb.org.

## Screenshots

![screen shot 2018-07-20 at 15 47 19](https://user-images.githubusercontent.com/26352280/42999306-740bdc86-8c47-11e8-97c3-d179242b3c11.png)
![screen shot 2018-07-20 at 15 47 34](https://user-images.githubusercontent.com/26352280/42999331-8b3bbda4-8c47-11e8-8255-41a26ce1dfb9.png)

## Setting API_KEY
Copy API_KEY (v3 auth) from www.themoviedb.org, and save in file```gradle.properties```.

```
# Input your Api Key
API_KEY="Input Your API Key"
```
