package id.chirikualii.cataloguemovie.ui.main;

public interface IMainPresenter {
    void peformSearch(String query);
    void performLoading();
}
